from django.shortcuts import render

# Create your views here.
def home(request):
    menu = request.GET.get('menu', '')
    return render(request, "index.html", {'menu':menu})


def about(request):
    menu = request.GET.get('menu', '')
    return render(request, "about.html", {'menu':menu})

def works(request):
    menu = request.GET.get('menu', '')
    return render(request, "works.html", {'menu':menu})

def blog(request):
    menu = request.GET.get('menu', '')
    return render(request, 'blog.html', {'menu':menu})    

def contact(request):
    menu = request.GET.get('menu', '')
    return render(request, "contact.html", {'menu':menu})