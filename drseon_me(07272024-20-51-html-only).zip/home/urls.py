from django.urls import path
from . import views


urlpatterns = [
# I don't use this urls.py
]