from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404
from django.core.mail import send_mail
from django.views.generic import ListView
from .models import Post, Comment
#from .forms import EmailPostForm, CommentForm, SubscriptionForm
from .forms import SubscriptionForm
from .models import Subscription
from taggit.models import Tag
from django.contrib import messages

# Create your views here.
def home(request):
    menu = request.GET.get('menu', '')
    return render(request, "index.html", {'menu':menu})

def about(request):
    menu = request.GET.get('menu', '')
    return render(request, "about.html", {'menu':menu})

def works(request):
    menu = request.GET.get('menu', '')
    return render(request, "works.html", {'menu':menu})

def blog(request, tag_slug=None):
    menu = request.GET.get('menu', '')
    posts = Post.published.all()
    tag = None

    if tag_slug:
        tag = get_object_or_404(Tag, slug=tag_slug)
        posts = posts.filter(tags__in=[tag])
    return render(request,'blog.html', {'posts': posts,'tag': tag,'menu':menu})

def blog_detail(request, year, month, day, post):
    menu = request.GET.get('menu', '')
    post = get_object_or_404(Post, 
                             slug=post,
                             status='published', 
                             publish__year=year, 
                             publish__month=month, 
                             publish__day=day)
    return render(request,'blog_detail.html', {'post': post, 'menu':menu})


def contact(request):
    menu = request.GET.get('menu', '')
    return render(request, "contact.html", {'menu':menu})

def subscribe(request):
    if request.method == 'POST':
        form = SubscriptionForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            if Subscription.objects.filter(email=email).exists():
                return render(request, 'exists.html')  # Render the thank you page
            else:
                Subscription.objects.filter(email=email)
                return render(request, 'thank_you.html')  # Render the thank you page
    else:
        form = SubscriptionForm()
    return redirect(request.META.get('HTTP_REFERER', '/blog?menu=blog'))