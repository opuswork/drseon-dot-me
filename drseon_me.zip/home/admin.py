from django.contrib import admin
from .models import Category, Post, Comment
from django_summernote.admin import SummernoteModelAdmin

class PostAdmin(SummernoteModelAdmin, admin.ModelAdmin):
    # Apply summernote to content field of your model
    list_display = ('title', 'slug', 'author', 'publish', 'status')
    list_filter = ('status', 'created', 'publish', 'author')
    search_fields = ('title', 'body')
    prepopulated_fields = {'slug': ('title',)}
    raw_id_fields = ('author',)
    date_hierarchy = 'publish'
    ordering = ('status', 'publish')
    summernote_fields = ('body',)

class CommentAdmin(SummernoteModelAdmin, admin.ModelAdmin):
    list_display = ('name', 'email', 'post', 'created','active')
    list_filter = ('active', 'created', 'updated')
    search_fields = ('name', 'email', 'body')
    summernote_fields = ('body',)    

# Register your models here.
admin.site.register(Category)
admin.site.register(Post, PostAdmin)
admin.site.register(Comment)
